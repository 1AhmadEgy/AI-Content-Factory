package com.example.data.repository

import android.util.Log
import com.example.core.model.*
import com.example.data.local.FactoryDao
import com.example.data.remote.BackendJob
import com.example.data.remote.CreateJobRequest
import com.example.data.remote.JobInputRequest
import com.example.data.remote.NetworkClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class Repository(private val dao: FactoryDao) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    // Do not construct Retrofit during Application startup. A malformed build-time API URL
    // would otherwise throw from Repository construction and force-close the app before UI.
    // Lazy initialization lets the existing coroutine error handling surface the failure safely.
    private val api by lazy { NetworkClient.apiService }
    private val isoParser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    val projects: StateFlow<List<Project>> = dao.getAllProjects().stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())
    val series: StateFlow<List<Series>> = dao.getAllSeries().stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())
    val episodes: StateFlow<List<Episode>> = dao.getAllEpisodes().stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())
    val scenes: StateFlow<List<Scene>> = dao.getAllScenes().stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())
    val jobs: StateFlow<List<GenerationJob>> = dao.getAllJobs().stateIn(scope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        scope.launch {
            try {
                syncJobs()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.e("Repository", "Initial job sync failed; continuing offline", e)
            }
        }
    }

    suspend fun addProject(name: String, description: String) {
        try {
            val project = api.createProject(ProjectCreateRequest(name, description)).data
            dao.insertProject(Project(id = project.id, name = project.name, description = project.description))
        } catch (e: Exception) {
            Log.e("Repository", "createProject failed", e)
            throw e
        }
    }

    suspend fun addSeries(projectId: String, title: String) {
        dao.insertSeries(Series(projectId = projectId, title = title))
    }

    suspend fun addEpisode(seriesId: String, number: Int, title: String) {
        val episode = Episode(seriesId = seriesId, number = number, title = title)
        dao.insertEpisode(episode)
        dao.findProjectIdForSeries(seriesId)?.let { projectId -> snapshotEpisodeContext(projectId, episode.id) }
    }

    private suspend fun snapshotEpisodeContext(projectId: String, episodeId: String) {
        api.snapshotEpisodeContext(projectId, episodeId)
    }

    suspend fun generateScene(sceneId: String) {
        val scene = scenes.value.find { it.id == sceneId } ?: return
        val projectId = dao.findProjectIdForScene(sceneId) ?: run {
            scene.status = "FAILED"
            dao.updateScene(scene)
            return
        }
        scene.status = "QUEUED"
        dao.updateScene(scene)
        try {
            val response = api.createJob(
                request = CreateJobRequest(
                    projectId = projectId,
                    type = "IMAGE",
                    targetType = "scene",
                    targetId = sceneId,
                    input = JobInputRequest(
                        parameters = mapOf(
                            "prompt" to "${scene.description}. Location: ${scene.location}. Emotion: ${scene.emotion}. Create a production-ready cinematic frame with consistent character and environment identity.",
                            "sceneId" to sceneId,
                            "description" to scene.description,
                            "location" to scene.location,
                            "emotion" to scene.emotion,
                        ),
                        deterministic = false,
                    ),
                ),
                idempotencyKey = "android-scene-$sceneId",
            )
            dao.insertJob(response.data.toLocalJob())
        } catch (e: Exception) {
            Log.e("Repository", "generateScene failed", e)
            scene.status = "FAILED"
            dao.updateScene(scene)
            throw e
        }
    }

    private fun parseTime(value: String?): Long? {
        if (value == null) return null
        val normalized = value.replace(Regex("\\.(\\d{3})\\d*Z$"), ".$1Z")
        return runCatching { synchronized(isoParser) { isoParser.parse(normalized)?.time } }.getOrNull()
    }

    private fun BackendJob.toLocalJob(): GenerationJob = GenerationJob(
        id = id,
        jobType = type,
        targetType = targetType,
        targetId = targetId,
        status = runCatching { JobStatus.valueOf(status.uppercase(Locale.US)) }.getOrDefault(JobStatus.FAILED),
        priority = priority,
        attempt = attempt,
        maxAttempts = maxAttempts,
        provider = provider,
        model = model,
        progress = (progress.coerceIn(0.0, 1.0) * 100).toInt(),
        errorCode = errorCode,
        errorMessage = errorMessage,
        createdAt = parseTime(createdAt) ?: System.currentTimeMillis(),
        startedAt = parseTime(startedAt),
        completedAt = parseTime(completedAt),
    )

    suspend fun syncJobs(projectId: String? = null) {
        // Batch into a single transaction instead of one insert (and one transaction) per job.
        dao.insertJobs(api.listJobs(projectId = projectId, limit = 200).data.map { it.toLocalJob() })
    }

    suspend fun cancelJob(jobId: String): GenerationJob? = api.cancelJob(jobId).data.toLocalJob().also { dao.insertJob(it) }

    suspend fun retryJob(jobId: String): GenerationJob? = api.retryJob(jobId).data.toLocalJob().also { dao.insertJob(it) }

    suspend fun refreshJob(jobId: String) {
        dao.insertJob(api.getJob(jobId).data.toLocalJob())
    }
}

object Graph {
    lateinit var repository: Repository

    fun provide(context: android.content.Context) {
        val appContext = context.applicationContext
        val database = try {
            com.example.data.local.FactoryDatabase.getDatabase(appContext)
        } catch (firstFailure: Throwable) {
            // A corrupted/incompatible local database should not permanently brick the app.
            // Room's normal migration fallback handles schema changes; this retry is a final
            // recovery path for an unreadable database. It may discard local cached data.
            Log.e("Graph", "Database initialization failed; recreating local database", firstFailure)
            appContext.deleteDatabase("factory_database")
            com.example.data.local.FactoryDatabase.getDatabase(appContext)
        }
        repository = Repository(database.factoryDao())
    }
}
