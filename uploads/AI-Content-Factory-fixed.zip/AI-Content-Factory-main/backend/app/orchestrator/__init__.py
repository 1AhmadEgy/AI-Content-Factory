"""Application orchestration boundary."""
