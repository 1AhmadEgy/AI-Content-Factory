"""Provider-agnostic domain layer."""
