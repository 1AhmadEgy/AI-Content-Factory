-- Structural content hierarchy (episodes/scenes/shots) that already exists in the SQLite
-- schema (see infrastructure/sqlite.py SQLiteStore.initialize) but was missing from the
-- PostgreSQL baseline in 001_initial.sql. Without this, PostgresEpisodeRepository /
-- PostgresSceneRepository / PostgresShotRepository (infrastructure/postgres_repositories.py)
-- have no tables to read from or write to on a fresh PostgreSQL database.

CREATE TABLE IF NOT EXISTS episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_episodes_project ON episodes(project_id);

CREATE TABLE IF NOT EXISTS scenes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  episode_id uuid NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
  title text NOT NULL,
  order_index integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_scenes_episode_order ON scenes(episode_id, order_index);

CREATE TABLE IF NOT EXISTS shots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scene_id uuid NOT NULL REFERENCES scenes(id) ON DELETE CASCADE,
  order_index integer NOT NULL,
  prompt text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_shots_scene_order ON shots(scene_id, order_index);

ALTER TABLE episodes ENABLE ROW LEVEL SECURITY;
-- scenes/shots are scoped indirectly through episodes/scenes; enable RLS directly on them too
-- once a policy can join back to projects.project_id (tracked as V2 Phase "Project Isolation").
