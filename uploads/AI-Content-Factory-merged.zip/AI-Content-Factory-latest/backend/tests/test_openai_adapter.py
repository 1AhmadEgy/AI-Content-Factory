from app.providers.openai_adapter import OpenAIModelAdapter
from app.providers.contracts import ProviderRequest


def test_openai_adapter_never_fabricates_without_credentials(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    adapter = OpenAIModelAdapter("gpt-5.6-luna", "TEXT")
    response = adapter.execute(ProviderRequest("gpt-5.6-luna", {"prompt": "hello"}))
    assert response.success is False
    assert response.error_code == "OPENAI_API_KEY_MISSING"
    assert response.output_text is None


def test_openai_adapter_health_requires_credentials(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    assert OpenAIModelAdapter("gpt-5.6-luna", "TEXT").health_check() is False


def test_openai_adapter_sends_idempotency_key_header(monkeypatch):
    """A retried job must reuse the OpenAI Idempotency-Key header, not a fresh one.

    Otherwise a worker crash between "request sent" and "response recorded" causes the
    retry to bill/generate a second time instead of OpenAI returning the original result.
    """
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    captured: dict[str, object] = {}

    class _FakeResponse:
        def read(self):
            return b'{"output_text": "hi"}'

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False

    def fake_urlopen(req, timeout=None):
        captured["headers"] = dict(req.headers)
        return _FakeResponse()

    monkeypatch.setattr("app.providers.openai_adapter.urllib.request.urlopen", fake_urlopen)

    adapter = OpenAIModelAdapter("gpt-5.6-luna", "TEXT")
    response = adapter.execute(ProviderRequest("gpt-5.6-luna", {"prompt": "hello"}, idempotency_key="job-123"))

    assert response.success is True
    # urllib.request.Request lower-cases/title-cases header names on storage; check case-insensitively.
    headers_lower = {k.lower(): v for k, v in captured["headers"].items()}
    assert headers_lower.get("idempotency-key") == "job-123"
