"""Integration tests for ``app.infrastructure.postgres_repositories``.

These need a real, disposable PostgreSQL database with ``migrations/001_initial.sql``
and ``migrations/005_episodes_scenes_shots.sql`` applied, and the ``psycopg`` package
installed (``pip install "psycopg[binary]"``). Neither is available in the environment
that wrote this file, so every test here is skipped unless ``AICF_POSTGRES_TEST_DSN``
is set — run it yourself once you have a scratch database, e.g.:

    createdb aicf_test
    psql aicf_test -f backend/migrations/001_initial.sql
    psql aicf_test -f backend/migrations/002_runtime_hardening.sql
    psql aicf_test -f backend/migrations/003_multilingual_series.sql
    psql aicf_test -f backend/migrations/004_rls_policies.sql
    psql aicf_test -f backend/migrations/005_episodes_scenes_shots.sql
    AICF_POSTGRES_TEST_DSN=postgresql:///aicf_test pytest backend/tests/test_postgres_repositories.py

This is the test the module docstring in ``postgres_repositories.py`` asks you to run
before pointing a real deployment at it — treat a failure here as a bug in that file,
not in your database.
"""

from __future__ import annotations

import os

import pytest

pytestmark = pytest.mark.skipif(
    not os.getenv("AICF_POSTGRES_TEST_DSN"),
    reason="Set AICF_POSTGRES_TEST_DSN to a scratch PostgreSQL database to run these",
)


@pytest.fixture()
def repositories():
    from app.infrastructure.postgres_repositories import PostgresRepositories
    from app.infrastructure.postgres_repository import PostgresRepositoryFactory

    factory = PostgresRepositoryFactory(dsn=os.environ["AICF_POSTGRES_TEST_DSN"])
    repos = PostgresRepositories(factory)
    yield repos
    # Best-effort cleanup so repeated local runs don't accumulate rows; a throwaway
    # test database can also just be dropped/recreated between full runs instead.
    with repos.store.connection.cursor() as cursor:
        cursor.execute("DELETE FROM jobs")
        cursor.execute("DELETE FROM shots")
        cursor.execute("DELETE FROM scenes")
        cursor.execute("DELETE FROM episodes")
        cursor.execute("DELETE FROM projects")
    repos.close()


def test_project_round_trip(repositories) -> None:
    from app.core.ids import new_id
    from app.domain.projects import Project

    project = Project(id=new_id(), name="Demo", description="A demo project", settings={"lang": "ar"})
    repositories.projects.create(project)

    fetched = repositories.projects.get(project.id)
    assert fetched is not None
    assert fetched.name == "Demo"
    assert fetched.settings == {"lang": "ar"}


def test_episode_scene_shot_hierarchy(repositories) -> None:
    from app.core.ids import new_id
    from app.domain.projects import Episode, Project, Scene, Shot

    project = Project(id=new_id(), name="Demo")
    repositories.projects.create(project)

    episode = Episode(id=new_id(), project_id=project.id, title="Episode 1")
    repositories.episodes.create(episode)
    assert repositories.episodes.get(episode.id).title == "Episode 1"

    scene = Scene(id=new_id(), episode_id=episode.id, title="Opening", order_index=0)
    repositories.scenes.create(scene)
    assert repositories.scenes.get(scene.id).order_index == 0

    shot = Shot(id=new_id(), scene_id=scene.id, order_index=0, prompt="wide shot")
    repositories.shots.create(shot)
    assert repositories.shots.get(shot.id).prompt == "wide shot"


def test_job_lifecycle_and_optimistic_update(repositories) -> None:
    from app.core.ids import new_id
    from app.domain.jobs import GenerationJob, JobStatus, JobType
    from app.domain.projects import Project

    project = Project(id=new_id(), name="Demo")
    repositories.projects.create(project)

    job = GenerationJob(id=new_id(), project_id=project.id, type=JobType.SCENE, target_type="scene")
    repositories.jobs.create(job)

    fetched = repositories.jobs.get(job.id)
    assert fetched is not None
    assert fetched.status == JobStatus.PENDING

    fetched.status = JobStatus.RUNNING
    fetched.attempt += 1
    assert repositories.jobs.update_if_current(fetched, JobStatus.PENDING, fetched.attempt - 1)

    # Stale caller (still thinks attempt is the old value) must be rejected.
    stale = repositories.jobs.get(job.id)
    stale.status = JobStatus.COMPLETED
    assert not repositories.jobs.update_if_current(stale, JobStatus.PENDING, 0)


def test_create_with_idempotency_returns_conflict_on_fingerprint_mismatch(repositories) -> None:
    from app.core.ids import new_id
    from app.domain.jobs import GenerationJob, JobType
    from app.domain.projects import Project

    project = Project(id=new_id(), name="Demo")
    repositories.projects.create(project)

    job_a = GenerationJob(id=new_id(), project_id=project.id, type=JobType.SCENE, target_type="scene")
    result_a = repositories.jobs.create_with_idempotency(
        job_a, key="idem-1", operation="create_scene_job", fingerprint="fp-1",
    )
    assert result_a.job is not None and result_a.conflict is False

    job_b = GenerationJob(id=new_id(), project_id=project.id, type=JobType.SCENE, target_type="scene")
    result_b = repositories.jobs.create_with_idempotency(
        job_b, key="idem-1", operation="create_scene_job", fingerprint="fp-2",
    )
    assert result_b.job is None
    assert result_b.conflict is True
