import time
import uuid

from app.core.config import Settings, get_settings
from app.core.errors import ConflictError, ForbiddenError, NotFoundError
from app.core.ids import is_valid_id, new_id, new_sortable_id
from app.core.timestamps import from_iso, to_iso, utc_now
from app.maintenance.startup_checks import run_startup_checks
from app.observability.request_context import bind, current_job_id, current_request_id


def test_new_id_is_a_valid_uuid() -> None:
    value = new_id()
    assert uuid.UUID(value)
    assert is_valid_id(value)


def test_sortable_ids_increase_with_time() -> None:
    first = new_sortable_id()
    # The millisecond-timestamp prefix only orders IDs generated in different
    # milliseconds; two calls in the same millisecond differ only in their
    # random suffix. Sleep past a millisecond boundary so the comparison
    # below is deterministic rather than occasionally flaky.
    time.sleep(0.002)
    second = new_sortable_id()
    assert first < second
    assert is_valid_id(first)


def test_sortable_id_with_prefix_round_trips_through_is_valid_id() -> None:
    value = new_sortable_id(prefix="job")
    assert value.startswith("job_")
    assert is_valid_id(value)


def test_timestamp_round_trip() -> None:
    now = utc_now()
    assert from_iso(to_iso(now)) == now
    assert to_iso(None) is None
    assert from_iso(None) is None


def test_app_errors_build_the_existing_envelope_shape() -> None:
    error = NotFoundError("Job not found", details={"jobId": "abc"})
    envelope = error.to_envelope("req-1")
    assert envelope == {
        "error": {
            "code": "NOT_FOUND",
            "message": "Job not found",
            "details": {"jobId": "abc"},
            "requestId": "req-1",
        }
    }
    assert error.status_code == 404
    assert ConflictError("x").status_code == 409
    assert ForbiddenError("x").status_code == 403


def test_settings_reads_environment(monkeypatch) -> None:
    monkeypatch.setenv("AICF_DATABASE_PATH", "/tmp/example.db")
    monkeypatch.setenv("AICF_WORKER_AUTOSTART", "true")
    get_settings.cache_clear()
    try:
        settings = get_settings()
        assert settings.database_path == "/tmp/example.db"
        assert settings.worker_autostart is True
    finally:
        get_settings.cache_clear()


def test_request_context_bind_is_scoped_and_reset() -> None:
    assert current_request_id() is None
    assert current_job_id() is None
    with bind(request_id="req-1", job_id="job-1"):
        assert current_request_id() == "req-1"
        assert current_job_id() == "job-1"
    assert current_request_id() is None
    assert current_job_id() is None


def test_startup_checks_report_asset_root_writable(tmp_path) -> None:
    settings = Settings(
        database_path=str(tmp_path / "data" / "factory.db"),
        asset_root=str(tmp_path / "assets"),
        test_mode=True,
    )
    report = run_startup_checks(settings)
    by_name = {check.name: check for check in report.checks}
    assert by_name["database_writable"].ok
    assert by_name["asset_root_writable"].ok
    assert by_name["auth_configured"].ok
