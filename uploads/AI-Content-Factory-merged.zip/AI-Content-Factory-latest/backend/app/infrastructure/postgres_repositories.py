"""PostgreSQL-backed repository implementations.

V2 master plan, Phase 3 ("PostgreSQL يصبح قاعدة الإنتاج").

``app/domain/repositories.py`` already defines the target interfaces
(``ProjectRepository``, ``EpisodeRepository``, ``SceneRepository``,
``ShotRepository``, ``JobRepository``) and ``infrastructure/sqlite.py``
already implements all of them for SQLite. ``postgres_repository.py`` only
provided a bare connection factory with no repository classes at all, so
until this file, "PostgreSQL as production" had no actual read/write path
for the SQLite-only implemented above; every one of these subclasses of the
domain ABCs implements the exact same domain contracts.

Requires ``psycopg`` (v3) and the migrations under ``backend/migrations``
applied in order (005_episodes_scenes_shots.sql adds the episodes/scenes/
shots tables this file depends on — they did not previously exist in the
PostgreSQL baseline).

IMPORTANT — this module has not been run against a live PostgreSQL server:
this environment has no network access to install ``psycopg`` or start a
PostgreSQL instance, and no existing automated test exercises it. The SQL
and psycopg3 API usage below is written to match the schema in
``migrations/001_initial.sql`` / ``005_episodes_scenes_shots.sql`` and the
domain dataclasses field-for-field, but treat it as a first draft: run
``backend/tests/test_postgres_repositories.py`` (see the companion test
file — it is skipped automatically unless ``AICF_POSTGRES_TEST_DSN`` points
at a real, disposable database) before pointing any real deployment at it.

ID convention: domain dataclasses store every ID as a plain ``str`` so the
same domain object works against SQLite's ``TEXT`` primary keys (which
accept arbitrary strings, e.g. ``"project-1"`` in tests) or PostgreSQL's
``uuid`` primary keys (which only accept actual UUID-shaped strings). Code
that creates entities meant for PostgreSQL must generate IDs with
``app.core.ids.new_id()`` (or an equivalent valid UUID) — see NotFoundError
usage below for the input-validation error this produces otherwise.
"""

from __future__ import annotations

from threading import RLock
from typing import Any

from ..core.errors import NotFoundError
from ..domain.jobs import GenerationJob, JobInput, JobOutput, JobStatus, JobType
from ..domain.projects import Episode, Project, Scene, Shot
from ..domain.repositories import (
    EpisodeRepository,
    IdempotencyResult,
    JobRepository,
    ProjectRepository,
    SceneRepository,
    ShotRepository,
)
from .postgres_repository import PostgresRepositoryFactory


def _job_input_to_dict(value: JobInput) -> dict[str, Any]:
    return {
        "parameters": value.parameters,
        "referenceAssetIds": value.reference_asset_ids,
        "constraints": value.constraints,
        "seed": value.seed,
        "deterministic": value.deterministic,
    }


def _job_input_from_dict(value: dict[str, Any]) -> JobInput:
    return JobInput(
        parameters=value.get("parameters", {}),
        reference_asset_ids=value.get("referenceAssetIds", []),
        constraints=value.get("constraints", {}),
        seed=value.get("seed"),
        deterministic=value.get("deterministic", False),
    )


def _job_output_to_dict(value: JobOutput | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {
        "assetIds": value.asset_ids,
        "metrics": value.metrics,
        "providerRunId": value.provider_run_id,
    }


def _job_output_from_dict(value: dict[str, Any] | None) -> JobOutput | None:
    if value is None:
        return None
    return JobOutput(
        asset_ids=value.get("assetIds", []),
        metrics=value.get("metrics", {}),
        provider_run_id=value.get("providerRunId"),
    )


def _json_wrap(value: Any):
    """Defer importing psycopg's Json wrapper to call time.

    Keeps ``import app.infrastructure.postgres_repositories`` cheap and
    side-effect-free for callers that only need the SQLite path and never
    installed psycopg (mirrors the lazy ``import psycopg`` already used in
    ``postgres_repository.py``).
    """
    from psycopg.types.json import Json

    return Json(value)


class PostgresStore:
    """Owns a single PostgreSQL connection, mirroring ``SQLiteStore``'s shape.

    A single shared connection guarded by a lock matches the concurrency
    model already used for SQLite in this codebase (``SQLiteStore``), so
    the two backends behave the same way under the existing thread-based
    worker model. A pooled connection (``psycopg_pool``) would scale
    better under concurrent API load, but that is a deliberate follow-up —
    swapping the concurrency model and validating it under load belongs in
    its own change, not bundled into "add PostgreSQL support at all".
    """

    def __init__(self, factory: PostgresRepositoryFactory) -> None:
        self._lock = RLock()
        self._connection = factory.connect()
        # Autocommit: each single-statement write commits immediately, matching the semantics
        # ``SQLiteStore`` gets from wrapping every write in ``with self._connection:``. Multi-
        # statement atomicity (the idempotency check-and-insert) opts back into an explicit
        # transaction with ``connection.transaction()`` — supported by psycopg3 even in
        # autocommit mode. Without this, psycopg3's default manual-commit mode would leave
        # every read in an open, uncommitted transaction until something else happened to
        # commit it.
        self._connection.autocommit = True

    @property
    def connection(self):
        return self._connection

    def close(self) -> None:
        with self._lock:
            self._connection.close()

    def _get(self, table: str, entity_id: str) -> dict[str, Any] | None:
        with self._lock, self._connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM {table} WHERE id = %s", (entity_id,))
            row = cursor.fetchone()
            if row is None:
                return None
            columns = [column.name for column in cursor.description]
            return dict(zip(columns, row))


class PostgresProjectRepository(ProjectRepository):
    def __init__(self, store: PostgresStore) -> None:
        self.store = store

    def create(self, project: Project) -> Project:
        with self.store._lock:
            self.store.connection.execute(
                "INSERT INTO projects(id,name,description,settings,created_at,updated_at) "
                "VALUES(%s,%s,%s,%s,%s,%s)",
                (
                    project.id, project.name, project.description,
                    _json_wrap(project.settings), project.created_at, project.updated_at,
                ),
            )
        return project

    def get(self, project_id: str) -> Project | None:
        row = self.store._get("projects", project_id)
        if row is None:
            return None
        return Project(
            id=str(row["id"]), name=row["name"], description=row["description"] or "",
            settings=row["settings"] or {}, created_at=row["created_at"], updated_at=row["updated_at"],
        )


class PostgresEpisodeRepository(EpisodeRepository):
    def __init__(self, store: PostgresStore) -> None:
        self.store = store

    def create(self, episode: Episode) -> Episode:
        with self.store._lock:
            self.store.connection.execute(
                "INSERT INTO episodes(id,project_id,title,created_at,updated_at) VALUES(%s,%s,%s,%s,%s)",
                (episode.id, episode.project_id, episode.title, episode.created_at, episode.updated_at),
            )
        return episode

    def get(self, episode_id: str) -> Episode | None:
        row = self.store._get("episodes", episode_id)
        if row is None:
            return None
        return Episode(
            id=str(row["id"]), project_id=str(row["project_id"]), title=row["title"],
            created_at=row["created_at"], updated_at=row["updated_at"],
        )


class PostgresSceneRepository(SceneRepository):
    def __init__(self, store: PostgresStore) -> None:
        self.store = store

    def create(self, scene: Scene) -> Scene:
        with self.store._lock:
            self.store.connection.execute(
                "INSERT INTO scenes(id,episode_id,title,order_index,created_at) VALUES(%s,%s,%s,%s,%s)",
                (scene.id, scene.episode_id, scene.title, scene.order_index, scene.created_at),
            )
        return scene

    def get(self, scene_id: str) -> Scene | None:
        row = self.store._get("scenes", scene_id)
        if row is None:
            return None
        return Scene(
            id=str(row["id"]), episode_id=str(row["episode_id"]), title=row["title"],
            order_index=row["order_index"], created_at=row["created_at"],
        )


class PostgresShotRepository(ShotRepository):
    def __init__(self, store: PostgresStore) -> None:
        self.store = store

    def create(self, shot: Shot) -> Shot:
        with self.store._lock:
            self.store.connection.execute(
                "INSERT INTO shots(id,scene_id,order_index,prompt,created_at) VALUES(%s,%s,%s,%s,%s)",
                (shot.id, shot.scene_id, shot.order_index, shot.prompt, shot.created_at),
            )
        return shot

    def get(self, shot_id: str) -> Shot | None:
        row = self.store._get("shots", shot_id)
        if row is None:
            return None
        return Shot(
            id=str(row["id"]), scene_id=str(row["scene_id"]), order_index=row["order_index"],
            prompt=row["prompt"] or "", created_at=row["created_at"],
        )


def _job_from_row(row: dict[str, Any]) -> GenerationJob:
    return GenerationJob(
        id=str(row["id"]),
        parent_job_id=str(row["parent_job_id"]) if row["parent_job_id"] else None,
        project_id=str(row["project_id"]), type=JobType(row["type"]), target_type=row["target_type"],
        target_id=row["target_id"], priority=row["priority"], status=JobStatus(row["status"]),
        progress=row["progress"], attempt=row["attempt"], max_attempts=row["max_attempts"],
        provider=row["provider"], model=row["model"],
        input=_job_input_from_dict(row["input"] or {}),
        output=_job_output_from_dict(row["output"]),
        error_code=row["error_code"], error_message=row["error_message"],
        created_at=row["created_at"], started_at=row["started_at"],
        completed_at=row["completed_at"], updated_at=row["updated_at"],
    )


class PostgresJobRepository(JobRepository):
    def __init__(self, store: PostgresStore) -> None:
        self.store = store

    def _insert_job(self, connection, job: GenerationJob) -> None:
        connection.execute(
            "INSERT INTO jobs(id,parent_job_id,project_id,type,target_type,target_id,priority,status,"
            "progress,attempt,max_attempts,provider,model,input,output,error_code,error_message,"
            "created_at,started_at,completed_at,updated_at) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (
                job.id, job.parent_job_id, job.project_id, job.type.value, job.target_type, job.target_id,
                job.priority, job.status.value, job.progress, job.attempt, job.max_attempts, job.provider,
                job.model, _json_wrap(_job_input_to_dict(job.input)),
                _json_wrap(_job_output_to_dict(job.output)) if job.output else None,
                job.error_code, job.error_message, job.created_at, job.started_at,
                job.completed_at, job.updated_at,
            ),
        )

    def create(self, job: GenerationJob) -> GenerationJob:
        with self.store._lock:
            self._insert_job(self.store.connection, job)
        return job

    def create_with_idempotency(
        self,
        job: GenerationJob,
        *,
        key: str,
        operation: str,
        fingerprint: str,
    ) -> IdempotencyResult:
        with self.store._lock:
            connection = self.store.connection
            with connection.transaction(), connection.cursor() as cursor:
                cursor.execute(
                    "SELECT operation, request_fingerprint, resource_id FROM idempotency_keys "
                    "WHERE key = %s FOR UPDATE",
                    (key,),
                )
                existing = cursor.fetchone()
                if existing is not None:
                    operation_col, fingerprint_col, resource_id = existing
                    matches = operation_col == operation and fingerprint_col == fingerprint
                    return IdempotencyResult(
                        job=None,
                        existing_resource_id=str(resource_id) if matches else None,
                        conflict=not matches,
                    )
                self._insert_job(cursor, job)
                cursor.execute(
                    "INSERT INTO idempotency_keys(key,operation,request_fingerprint,resource_id,created_at) "
                    "VALUES(%s,%s,%s,%s,now())",
                    (key, operation, fingerprint, job.id),
                )
                return IdempotencyResult(job=job)

    def get(self, job_id: str) -> GenerationJob | None:
        row = self.store._get("jobs", job_id)
        return _job_from_row(row) if row else None

    def update(self, job: GenerationJob) -> GenerationJob:
        with self.store._lock:
            cursor = self.store.connection.execute(
                "UPDATE jobs SET parent_job_id=%s,project_id=%s,type=%s,target_type=%s,target_id=%s,"
                "priority=%s,status=%s,progress=%s,attempt=%s,max_attempts=%s,provider=%s,model=%s,"
                "input=%s,output=%s,error_code=%s,error_message=%s,started_at=%s,completed_at=%s,"
                "updated_at=%s WHERE id=%s",
                (
                    job.parent_job_id, job.project_id, job.type.value, job.target_type, job.target_id,
                    job.priority, job.status.value, job.progress, job.attempt, job.max_attempts,
                    job.provider, job.model, _json_wrap(_job_input_to_dict(job.input)),
                    _json_wrap(_job_output_to_dict(job.output)) if job.output else None,
                    job.error_code, job.error_message, job.started_at, job.completed_at,
                    job.updated_at, job.id,
                ),
            )
            if cursor.rowcount != 1:
                raise NotFoundError(f"Job not found: {job.id}", details={"jobId": job.id})
        return job

    def update_if_current(
        self,
        job: GenerationJob,
        expected_status: JobStatus,
        expected_attempt: int,
    ) -> bool:
        with self.store._lock:
            cursor = self.store.connection.execute(
                "UPDATE jobs SET parent_job_id=%s,project_id=%s,type=%s,target_type=%s,target_id=%s,"
                "priority=%s,status=%s,progress=%s,attempt=%s,max_attempts=%s,provider=%s,model=%s,"
                "input=%s,output=%s,error_code=%s,error_message=%s,started_at=%s,completed_at=%s,"
                "updated_at=%s WHERE id=%s AND status=%s AND attempt=%s",
                (
                    job.parent_job_id, job.project_id, job.type.value, job.target_type, job.target_id,
                    job.priority, job.status.value, job.progress, job.attempt, job.max_attempts,
                    job.provider, job.model, _json_wrap(_job_input_to_dict(job.input)),
                    _json_wrap(_job_output_to_dict(job.output)) if job.output else None,
                    job.error_code, job.error_message, job.started_at, job.completed_at,
                    job.updated_at, job.id, expected_status.value, expected_attempt,
                ),
            )
            return cursor.rowcount == 1

    def list_by_parent(self, parent_job_id: str) -> list[GenerationJob]:
        with self.store._lock, self.store.connection.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM jobs WHERE parent_job_id = %s ORDER BY created_at, id",
                (parent_job_id,),
            )
            columns = [column.name for column in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return [_job_from_row(row) for row in rows]

    def list(
        self,
        *,
        project_id: str | None = None,
        status: JobStatus | None = None,
        limit: int = 50,
    ) -> list[GenerationJob]:
        limit = max(1, min(limit, 200))
        clauses: list[str] = []
        params: list[Any] = []
        if project_id:
            clauses.append("project_id = %s")
            params.append(project_id)
        if status:
            clauses.append("status = %s")
            params.append(status.value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        with self.store._lock, self.store.connection.cursor() as cursor:
            cursor.execute(
                f"SELECT * FROM jobs{where} ORDER BY created_at DESC, id DESC LIMIT %s",
                (*params, limit),
            )
            columns = [column.name for column in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return [_job_from_row(row) for row in rows]


class PostgresRepositories:
    """Aggregates all PostgreSQL repositories, mirroring ``SQLiteRepositories``.

    Usage (once ``AICF_POSTGRES_DSN`` is configured and ``psycopg`` is
    installed)::

        factory = PostgresRepositoryFactory()
        repositories = PostgresRepositories(factory)
        project = repositories.projects.get(project_id)
    """

    def __init__(self, factory: PostgresRepositoryFactory) -> None:
        self.store = PostgresStore(factory)
        self.projects = PostgresProjectRepository(self.store)
        self.episodes = PostgresEpisodeRepository(self.store)
        self.scenes = PostgresSceneRepository(self.store)
        self.shots = PostgresShotRepository(self.store)
        self.jobs = PostgresJobRepository(self.store)

    def close(self) -> None:
        self.store.close()
