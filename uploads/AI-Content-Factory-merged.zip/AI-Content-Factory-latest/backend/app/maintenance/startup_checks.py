"""Startup health checks.

V2 foundation module (see V2 master plan, Phase 1 / "تثبيت الأساس").

Today a missing dependency (ffmpeg not on PATH, an unwritable database
directory, ``AICF_API_KEY`` unset outside test mode) surfaces later, as a
confusing failure on the first request or the first job execution — e.g.
``FfmpegRenderer.health_check()`` already exists and is called from the
``/api/v1/system`` router, but nothing calls it *before* the server starts
accepting traffic.

``run_startup_checks()`` collects the same kind of checks into one report
so an operator (or a CI job) can call it once, up front, and get every
misconfiguration at once instead of one-at-a-time. It intentionally
returns a report rather than raising or calling ``sys.exit`` itself: the
existing offline/mock-first design (see REPAIR_ROADMAP.md) means a missing
ffmpeg binary, for instance, should not always be fatal — that decision
belongs to the entrypoint (``main.py``) or a CI step, not to this module.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from ..core.config import Settings


@dataclass(frozen=True, slots=True)
class CheckResult:
    name: str
    ok: bool
    detail: str = ""


@dataclass(frozen=True, slots=True)
class StartupReport:
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(check.ok for check in self.checks)

    @property
    def failures(self) -> list[CheckResult]:
        return [check for check in self.checks if not check.ok]


def _check_database_writable(settings: Settings) -> CheckResult:
    if settings.database_path == ":memory:":
        return CheckResult("database_writable", True, "in-memory database")
    path = Path(settings.database_path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        probe = path.parent / ".aicf_startup_write_check"
        probe.write_text("ok")
        probe.unlink()
        return CheckResult("database_writable", True, str(path.parent))
    except OSError as exc:
        return CheckResult("database_writable", False, f"{path.parent}: {exc}")


def _check_asset_root_writable(settings: Settings) -> CheckResult:
    path = Path(settings.asset_root)
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".aicf_startup_write_check"
        probe.write_text("ok")
        probe.unlink()
        return CheckResult("asset_root_writable", True, str(path))
    except OSError as exc:
        return CheckResult("asset_root_writable", False, f"{path}: {exc}")


def _check_binary_available(name: str, binary: str) -> CheckResult:
    resolved = shutil.which(binary)
    if resolved is None:
        return CheckResult(name, False, f"'{binary}' not found on PATH")
    try:
        completed = subprocess.run([binary, "-version"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return CheckResult(name, False, f"'{binary}' found at {resolved} but did not respond: {exc}")
    return CheckResult(name, completed.returncode == 0, resolved)


def _check_auth_configured(settings: Settings) -> CheckResult:
    if settings.test_mode:
        return CheckResult("auth_configured", True, "AICF_TEST_MODE enabled; auth bypass expected")
    if settings.api_key:
        return CheckResult("auth_configured", True, "AICF_API_KEY set")
    return CheckResult("auth_configured", False, "AICF_API_KEY is empty and AICF_TEST_MODE is not enabled")


def run_startup_checks(settings: Settings) -> StartupReport:
    checks = [
        _check_database_writable(settings),
        _check_asset_root_writable(settings),
        _check_binary_available("ffmpeg_available", settings.ffmpeg_bin),
        _check_binary_available("ffprobe_available", settings.ffprobe_bin),
        _check_auth_configured(settings),
    ]
    return StartupReport(checks=checks)
