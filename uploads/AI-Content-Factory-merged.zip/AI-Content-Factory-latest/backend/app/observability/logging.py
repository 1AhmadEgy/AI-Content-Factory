"""Structured (JSON) logging setup.

V2 foundation module (see STATUS_AUDIT.md, immediate repair order item 5).

Existing code already uses the standard ``logging`` module (e.g.
``backend/app/orchestrator/job_executor.py``); this module does not
replace those ``logger = logging.getLogger(__name__)`` call sites — it
gives ``main.py`` (or a future entrypoint) one function to call once at
startup to make every one of those existing loggers emit structured JSON
lines with the correlation IDs from
:mod:`app.observability.request_context` attached automatically, with no
change needed at any individual ``logger.info(...)`` call site.

Not wired into ``main.py`` in this pass: changing the process-wide logging
configuration is exactly the kind of change that is safe in isolation but
risky to make blind, since it can affect what existing tests assert about
captured log output (``caplog``). It's ready to adopt with a one-line
``setup_logging()`` call once the test suite can confirm nothing depends on
the current plain-text format.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from .request_context import current_job_id, current_request_id


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        request_id = current_request_id()
        job_id = current_job_id()
        if request_id is not None:
            payload["requestId"] = request_id
        if job_id is not None:
            payload["jobId"] = job_id
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def setup_logging(level: int = logging.INFO) -> None:
    """Configure the root logger to emit one JSON object per line.

    Idempotent: safe to call more than once (e.g. once from ``main.py`` and
    once from a worker entrypoint) — existing handlers on the root logger
    are replaced rather than duplicated.
    """
    root = logging.getLogger()
    root.setLevel(level)
    for handler in list(root.handlers):
        root.removeHandler(handler)
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root.addHandler(handler)
