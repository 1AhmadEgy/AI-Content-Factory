"""Request/job correlation ID propagation.

V2 foundation module (see STATUS_AUDIT.md, immediate repair order item 5:
"Add structured correlation IDs/logging and metrics").

``main.py`` already assigns a per-request ID (``request.state.request_id``,
returned as ``X-Request-Id``) for API requests. That mechanism is tied to
Starlette's ``Request`` object, so it is only reachable from inside a route
handler — background worker threads (``JobExecutor``, ``WorkerLoop``,
render/publish workers) have no equivalent, so a log line emitted while
executing a job cannot currently be correlated back to the job or the
request that created it.

``contextvars.ContextVar`` works across both: it is set per-request in API
code and per-job in worker code, and automatically isolated between
concurrent asyncio tasks *and* threads that copy the context (each
``threading.Thread`` gets its own context unless explicitly copied, so
worker threads should call :func:`bind` explicitly at the start of job
execution — see the docstring on :func:`bind`).
"""

from __future__ import annotations

import contextvars
from contextlib import contextmanager
from typing import Iterator

_request_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("request_id", default=None)
_job_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("job_id", default=None)


def current_request_id() -> str | None:
    return _request_id.get()


def current_job_id() -> str | None:
    return _job_id.get()


@contextmanager
def bind(*, request_id: str | None = None, job_id: str | None = None) -> Iterator[None]:
    """Bind correlation IDs for the duration of a ``with`` block.

    Unlike an asyncio task (which inherits the context of the coroutine
    that spawned it), a plain ``threading.Thread`` starts with a *fresh*
    context. A worker thread's run loop should therefore call this once
    per job, right after leasing it::

        with bind(job_id=job.id):
            execute(job)
    """
    request_token = _request_id.set(request_id) if request_id is not None else None
    job_token = _job_id.set(job_id) if job_id is not None else None
    try:
        yield
    finally:
        if request_token is not None:
            _request_id.reset(request_token)
        if job_token is not None:
            _job_id.reset(job_token)
