from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ModelCapability:
    category: str
    capabilities: frozenset[str] = field(default_factory=frozenset)
    runtime: str = "CUSTOM"
    license_status: str = "UNKNOWN"


@dataclass(frozen=True, slots=True)
class ProviderRequest:
    model: str
    parameters: dict[str, Any] = field(default_factory=dict)
    seed: int | None = None
    # Stable across every retry of the *same* logical job (unlike a per-attempt key), so a
    # provider that honors it (OpenAI does, via the "Idempotency-Key" request header) returns
    # the original result instead of billing/generating a second time if a worker crashes or
    # times out after the request reached the provider but before the response was recorded.
    # Optional and defaulted so existing adapters/tests that build ProviderRequest directly
    # are unaffected; adapters that can't use it (no provider-side idempotency support) just
    # ignore it.
    idempotency_key: str | None = None


@dataclass(frozen=True, slots=True)
class ProviderResponse:
    success: bool
    output_asset_ids: list[str] = field(default_factory=list)
    output_text: str | None = None
    output_bytes: bytes | None = None
    output_mime_type: str | None = None
    output_filename: str | None = None
    output_metadata: dict[str, Any] = field(default_factory=dict)
    provider_run_id: str | None = None
    metrics: dict[str, float] = field(default_factory=dict)
    error_code: str | None = None
    error_message: str | None = None


class ModelAdapter(ABC):
    @abstractmethod
    def capability(self) -> ModelCapability: ...

    @abstractmethod
    def health_check(self) -> bool: ...

    @abstractmethod
    def execute(self, request: ProviderRequest) -> ProviderResponse: ...

    @abstractmethod
    def cancel(self, provider_run_id: str) -> bool: ...
