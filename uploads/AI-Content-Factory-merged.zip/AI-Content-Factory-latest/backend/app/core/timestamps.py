"""Canonical timestamp helpers.

V2 foundation module (see REPAIR_ROADMAP.md / V2 master plan, Phase 1).

Every persisted timestamp in this codebase should go through these three
functions so there is exactly one definition of "now", one serialization
format, and one parser. Existing call sites (``domain.jobs.utc_now`` and the
private ``_dt`` / ``_parse_dt`` helpers in ``infrastructure/sqlite.py``) are
left untouched for this pass — this module re-exports the same behaviour
under ``app.core`` so *new* code has one obvious place to import from,
without changing any already-tested call site in the same commit.
"""

from __future__ import annotations

from datetime import datetime, timezone

__all__ = ["utc_now", "to_iso", "from_iso"]


def utc_now() -> datetime:
    """Return the current time as a timezone-aware UTC datetime.

    Equivalent to ``app.domain.jobs.utc_now`` — kept in sync deliberately.
    """
    return datetime.now(timezone.utc)


def to_iso(value: datetime | None) -> str | None:
    """Serialize a datetime the same way ``infrastructure/sqlite.py`` does."""
    return value.isoformat() if value is not None else None


def from_iso(value: str | None) -> datetime | None:
    """Parse a timestamp previously produced by :func:`to_iso`."""
    return datetime.fromisoformat(value) if value is not None else None
