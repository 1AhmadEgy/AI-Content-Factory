"""Centralized, typed configuration snapshot.

V2 foundation module (see V2 master plan, Phase 1 / "تثبيت الأساس").

Today every ``AICF_*`` environment variable is read ad hoc, with
``os.getenv("AICF_...", default)`` repeated at each call site (queue
heartbeat interval, provider cache TTL, scheduler interval, asset root,
database path, ...). That works, but it means the full list of
configuration knobs is not documented anywhere in one place, and a typo in
an env var name fails silently by falling back to the default instead of
raising at startup.

This module does **not** replace any of those existing ``os.getenv(...)``
call sites yet — doing that is a mechanical but wide-reaching change
across ~15 files, and the only safe way to do it is one file at a time
with the test suite green after each, which this environment cannot run
(no network access to install fastapi/pytest here). Introducing
``Settings`` additively now means:

- New V2 code has one typed object to depend on instead of adding a 30th
  ad hoc ``os.getenv`` call site.
- The full set of recognized environment variables is documented in one
  place (this file), which the existing scattered call sites are not.
- Migrating an existing call site later is a small, independently
  reviewable diff: replace ``os.getenv("AICF_X", "default")`` with
  ``get_settings().x`` in that one file, run that file's tests, move on.

Usage::

    from app.core.config import get_settings
    settings = get_settings()
    settings.provider_cache_ttl_seconds
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache


def _bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    return float(raw) if raw is not None else default


def _int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    return int(raw) if raw is not None else default


@dataclass(frozen=True, slots=True)
class Settings:
    # Persistence
    database_path: str = field(default_factory=lambda: os.getenv("AICF_DATABASE_PATH", "./data/factory.db"))
    postgres_dsn: str = field(default_factory=lambda: os.getenv("AICF_POSTGRES_DSN", ""))
    asset_root: str = field(default_factory=lambda: os.getenv("AICF_ASSET_ROOT", "./data/assets"))

    # Auth
    api_key: str = field(default_factory=lambda: os.getenv("AICF_API_KEY", "").strip())
    test_mode: bool = field(default_factory=lambda: _bool_env("AICF_TEST_MODE", False))

    # Worker / queue
    worker_id: str = field(default_factory=lambda: os.getenv("AICF_WORKER_ID", "auto"))
    worker_autostart: bool = field(default_factory=lambda: _bool_env("AICF_WORKER_AUTOSTART", False))
    lease_heartbeat_seconds: float = field(default_factory=lambda: _float_env("AICF_LEASE_HEARTBEAT_SECONDS", 5.0))
    progress_persist_seconds: float = field(default_factory=lambda: _float_env("AICF_PROGRESS_PERSIST_SECONDS", 0.5))

    # Scheduler
    scheduler_autostart: bool = field(default_factory=lambda: _bool_env("AICF_SCHEDULER_AUTOSTART", True))
    scheduler_interval_seconds: float = field(default_factory=lambda: _float_env("AICF_SCHEDULER_INTERVAL_SECONDS", 5.0))

    # Providers
    openai_api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", "").strip())
    openai_base_url: str = field(default_factory=lambda: os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"))
    text_model: str = field(default_factory=lambda: os.getenv("AICF_TEXT_MODEL", "gpt-5.6-luna"))
    image_model: str = field(default_factory=lambda: os.getenv("AICF_IMAGE_MODEL", "gpt-image-2"))
    tts_model: str = field(default_factory=lambda: os.getenv("AICF_TTS_MODEL", "gpt-4o-mini-tts"))
    provider_timeout_seconds: float = field(default_factory=lambda: _float_env("AICF_PROVIDER_TIMEOUT_SECONDS", 120.0))

    # Circuit breaker
    circuit_fail_threshold: int = field(default_factory=lambda: _int_env("AICF_CIRCUIT_FAIL_THRESHOLD", 5))
    circuit_success_threshold: int = field(default_factory=lambda: _int_env("AICF_CIRCUIT_SUCCESS_THRESHOLD", 2))
    circuit_open_duration_seconds: float = field(default_factory=lambda: _float_env("AICF_CIRCUIT_OPEN_DURATION_SECONDS", 60.0))
    circuit_half_open_max_calls: int = field(default_factory=lambda: _int_env("AICF_CIRCUIT_HALF_OPEN_MAX_CALLS", 2))

    # Provider cache
    provider_cache_ttl_seconds: int = field(default_factory=lambda: _int_env("AICF_PROVIDER_CACHE_TTL_SECONDS", 86400))
    provider_cache_max_bytes: int = field(default_factory=lambda: _int_env("AICF_PROVIDER_CACHE_MAX_BYTES", 20 * 1024 * 1024))
    provider_cache_lock_seconds: int = field(default_factory=lambda: _int_env("AICF_PROVIDER_CACHE_LOCK_SECONDS", 30))
    provider_cache_wait_seconds: float = field(default_factory=lambda: _float_env("AICF_PROVIDER_CACHE_WAIT_SECONDS", 2.0))

    # Rendering
    ffmpeg_bin: str = field(default_factory=lambda: os.getenv("AICF_FFMPEG_BIN", "ffmpeg"))
    ffprobe_bin: str = field(default_factory=lambda: os.getenv("AICF_FFPROBE_BIN", "ffprobe"))

    # Library seeding
    seed_default_library: bool = field(default_factory=lambda: _bool_env("AICF_SEED_DEFAULT_LIBRARY", True))
    seed_libya_library: bool = field(default_factory=lambda: _bool_env("AICF_SEED_LIBYA_LIBRARY", True))
    seed_country_libraries: bool = field(default_factory=lambda: _bool_env("AICF_SEED_COUNTRY_LIBRARIES", True))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings snapshot, read once and cached.

    Tests that need a different environment should call
    ``get_settings.cache_clear()`` after changing ``os.environ`` (standard
    ``lru_cache`` pattern) rather than constructing ``Settings()`` directly,
    so production code always goes through one shared instance.
    """
    return Settings()
