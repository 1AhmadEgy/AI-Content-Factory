"""Canonical ID generation.

V2 foundation module (see V2 master plan, Phase 1 / "تثبيت الأساس").

The existing codebase already generates IDs several different ways
(``uuid.uuid4().hex`` in ``provider_cache.py``, ``str(uuid4())`` elsewhere,
Kotlin ``UUID.randomUUID().toString()`` on the Android side). This module
does not change any of those existing call sites — that would touch many
files at once with no way to run the test suite here to confirm nothing
broke. Instead it gives *new* V2 entities (organizations, users, project
memberships, job DAG nodes, ...) one canonical, sortable ID scheme to start
from, so they don't add a fourth convention on top of the existing three.

``new_id()`` returns a lowercase, hyphenated UUID4 — identical in shape to
``str(uuid.uuid4())`` — so it is a drop-in match for existing TEXT/UUID
primary key columns (SQLite ``TEXT`` and PostgreSQL ``uuid``/``text``).

``new_sortable_id()`` prefixes that UUID with a millisecond UTC timestamp,
so IDs generated later sort after IDs generated earlier — useful for
job-DAG nodes and event logs where insertion order matters and you want
that order without a separate ``created_at`` index lookup.
"""

from __future__ import annotations

import time
import uuid

__all__ = ["new_id", "new_sortable_id", "is_valid_id"]


def new_id() -> str:
    """Return a new random UUID4 string, e.g. ``"3f1c9e6a-..."``."""
    return str(uuid.uuid4())


def new_sortable_id(prefix: str = "") -> str:
    """Return a lexicographically time-sortable ID.

    Format: ``[<prefix>_]<13-digit-millis><uuid4-hex>``. Safe as a TEXT
    primary key in both SQLite and PostgreSQL.
    """
    millis = f"{int(time.time() * 1000):013d}"
    raw = f"{millis}{uuid.uuid4().hex}"
    return f"{prefix}_{raw}" if prefix else raw


def is_valid_id(value: str) -> bool:
    """Best-effort validity check for an ID produced by this module.

    Accepts both plain UUID4 strings (:func:`new_id`) and sortable IDs
    (:func:`new_sortable_id`). Intended for defensive validation of IDs
    coming from an external client (e.g. a path parameter) before they are
    used in a query — not a cryptographic or uniqueness guarantee.
    """
    if not value or len(value) > 128:
        return False
    try:
        uuid.UUID(value)
        return True
    except ValueError:
        pass
    body = value.rsplit("_", 1)[-1]
    return len(body) >= 13 + 32 and body[:13].isdigit()
