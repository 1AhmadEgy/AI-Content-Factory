"""Canonical application error hierarchy.

V2 foundation module (see V2 master plan, Phase 1 / "تثبيت الأساس").

``main.py`` already has a consistent JSON error envelope::

    {"error": {"code": ..., "message": ..., "details": {...}, "requestId": ...}}

but that shape is built ad hoc, inline, at each raise site (see the
handlers in ``main.py`` and the scattered ``HTTPException(status_code=...,
detail="SOME_CODE")`` calls across ``backend/app/api/v1/*``). This module
gives new code a single typed exception to raise instead, so the envelope
is built once, in one place.

This is intentionally *not* wired into ``main.py`` or the existing routers
in this pass: swapping every existing ``HTTPException`` call site for
``AppError`` subclasses touches dozens of files at once, and the only way
to be sure that doesn't silently change a response code or a test
expectation is to run the full backend test suite after each file — which
this environment cannot do (no network to install fastapi/pytest). Until
that migration is done incrementally with tests passing at each step, new
V2 code can raise these and they will still be handled by FastAPI's
default exception handling; only ``main.py``'s registered handler for
``AppError`` (once added) needs to translate it into the existing envelope.
"""

from __future__ import annotations

from typing import Any


class AppError(Exception):
    """Base class for all domain/application errors with a stable error code.

    Subclass per failure family (see below) rather than raising ``AppError``
    directly, so callers can catch a specific kind without string-matching
    ``code``.
    """

    code: str = "APPLICATION_ERROR"
    status_code: int = 500

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def to_envelope(self, request_id: str) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "details": self.details,
                "requestId": request_id,
            }
        }


class NotFoundError(AppError):
    """The requested resource does not exist (or is not visible to the caller)."""

    code = "NOT_FOUND"
    status_code = 404


class ValidationError(AppError):
    """The request was well-formed but failed domain/business validation."""

    code = "VALIDATION_ERROR"
    status_code = 422


class ConflictError(AppError):
    """The request conflicts with the resource's current state (e.g. a terminal job)."""

    code = "CONFLICT"
    status_code = 409


class UnauthorizedError(AppError):
    """No valid credentials were presented."""

    code = "UNAUTHORIZED"
    status_code = 401


class ForbiddenError(AppError):
    """Valid credentials were presented, but they don't grant access to this resource.

    Distinct from :class:`UnauthorizedError` on purpose: once project/user
    ownership checks exist (V2 master plan, "Project Isolation"), a caller
    who is authenticated but does not own the resource must get 403, not a
    404 that leaks whether the resource exists, nor a 401 that wrongly
    suggests their credentials themselves are invalid.
    """

    code = "FORBIDDEN"
    status_code = 403


class DependencyUnavailableError(AppError):
    """A required external dependency (provider, ffmpeg, storage) is unavailable."""

    code = "DEPENDENCY_UNAVAILABLE"
    status_code = 503
